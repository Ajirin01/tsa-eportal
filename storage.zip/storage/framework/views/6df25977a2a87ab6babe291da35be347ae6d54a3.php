
<li class="nav-item">
    <a href="<?php echo e(route('my_children')); ?>" class="nav-link <?php echo e(in_array(Route::currentRouteName(), ['my_children']) ? 'active' : ''); ?>"><i class="icon-users4"></i> My Children</a>
</li><?php /**PATH C:\wamp64\www\lav_sms-master\resources\views/pages/parent/menu.blade.php ENDPATH**/ ?>