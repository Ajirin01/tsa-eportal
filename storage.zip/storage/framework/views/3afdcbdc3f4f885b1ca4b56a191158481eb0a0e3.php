<form class="ajax-update" action="<?php echo e(route('marks.update', [$exam_id, $my_class_id, $section_id, $subject_id])); ?>" method="post">
    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
    <table class="table table-striped">
        <thead>
        <tr>
            <th>S/N</th>
            <th>Name</th>
            <th>ADM_NO</th>
            <?php if($class_type->code == 'J'): ?>
                <th>1ST CA (10)</th>
                <th>MT CA (20)</th>
                <th>2ND CA (10)</th>
                <th>EXAM (60)</th>
            <?php endif; ?>
            <?php if($class_type->code == 'S'): ?>
                <th>1ST CA (5)</th>
                <th>MID CA (15)</th>
                <th>2ND CA (10)</th>
                <th>EXAM (70)</th>
            <?php endif; ?>
            <?php if($class_type->code == 'P'): ?>
                <th>1ST CA (10)</th>
                <th>2ND CA (10)</th>
                <th>MT CA (20)</th>
                <th>EXAM (60)</th>
            <?php endif; ?>
            <?php if($class_type->code == 'N'): ?>
                <th>TEST (40)</th>
                <th>EXAM (60)</th>
            <?php endif; ?>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $marks->sortBy('user.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($mk->user->name); ?> </td>
                <td><?php echo e($mk->user->student_record->adm_no); ?></td>

                <?php if($class_type->code == 'J'): ?>
                    <td><input title="1ST CA" min="1" max="10" class="text-center" name="t1_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t1); ?>" type="number"></td>
                    <td><input title="MID CA" min="1" max="20" class="text-center" name="t2_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t2); ?>" type="number"></td>
                    <td><input title="2ND CA" min="1" max="10" class="text-center" name="t3_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t3); ?>" type="number"></td>
                    <td><input title="EXAM" min="1" max="60" class="text-center" name="exm_<?php echo e($mk->id); ?>" value="<?php echo e($mk->exm); ?>" type="number"></td>
                <?php endif; ?>

                <?php if($class_type->code == 'S'): ?>
                    <td><input title="1ST CA" min="1" max="5" class="text-center" name="t1_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t1); ?>" type="number"></td>
                    <td><input title="MID CA" min="1" max="15" class="text-center" name="t2_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t2); ?>" type="number"></td>
                    <td><input title="2ND CA" min="1" max="10" class="text-center" name="t3_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t3); ?>" type="number"></td>
                    <td><input title="EXAM" min="1" max="70" class="text-center" name="exm_<?php echo e($mk->id); ?>" value="<?php echo e($mk->exm); ?>" type="number"></td>
                <?php endif; ?>

                <?php if($class_type->code == 'P'): ?>
                    <td><input title="1ST CA" min="1" max=10 class="text-center" name="t1_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t1); ?>" type="number"></td>
                    <td><input title="2ND CA" min="1" max="10" class="text-center" name="t2_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t2); ?>" type="number"></td>
                    <td><input title="MID CA" min="1" max="20" class="text-center" name="t3_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t3); ?>" type="number"></td>
                    <td><input title="EXAM" min="1" max="60" class="text-center" name="exm_<?php echo e($mk->id); ?>" value="<?php echo e($mk->exm); ?>" type="number"></td>
                <?php endif; ?>

                <?php if($class_type->code == 'N'): ?>
                    <td><input title="TEST" min="1" max="40" class="text-center" name="t1_<?php echo e($mk->id); ?>" value="<?php echo e($mk->t1); ?>" type="number"></td>
                    <td><input title="EXAM" min="1" max="60" class="text-center" name="exm_<?php echo e($mk->id); ?>" value="<?php echo e($mk->exm); ?>" type="number"></td>
                <?php endif; ?>


            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <div class="text-center mt-2">
        <button type="submit" class="btn btn-primary">Update Marks <i class="icon-paperplane ml-2"></i></button>
    </div>
</form>
<?php /**PATH C:\wamp64\www\lav_sms-master\resources\views/pages/support_team/marks/edit.blade.php ENDPATH**/ ?>